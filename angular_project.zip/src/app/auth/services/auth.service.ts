import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private httpClient: HttpClient) {}

  // This registerUser should help us to do a rest call
  registerUser(data: any): Observable<any> {
    return this.httpClient.post('/api/users', data);
  }

  loginUser(data: any): Observable<any> {
    console.log('from loginUser() of authServcie');
    return this.httpClient.post('/api/auth', data);
  }
  //used to load the user
  loadUser(): Observable<any> {
    return this.httpClient.get('/api/auth');
  }
}
