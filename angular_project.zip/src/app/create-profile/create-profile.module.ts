import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { httpInterceptorProviders } from '../core/interceptors';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';

@NgModule({
  declarations: [CreateProfileComponent],
  imports: [CommonModule, HttpClientModule, FormsModule],
  providers: [httpInterceptorProviders],
})
export class CreateProfileModule {}
