import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfilesRoutingModule } from './profiles-routing.module';
import { ProfilesComponent } from './components/profiles/profiles.component';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';
import { httpInterceptorProviders } from '../core/interceptors';
import { ProfilesService } from './services/profiles.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [ProfilesComponent, ProfileItemComponent],
  imports: [CommonModule, FormsModule, HttpClientModule, ProfilesRoutingModule],
  providers: [httpInterceptorProviders, ProfilesService],
})
export class ProfilesModule {}
